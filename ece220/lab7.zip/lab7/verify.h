#ifndef VERIFY_H
#define VERIFY_H
extern unsigned int N;
void backtracking_gold( unsigned int index, int chosen[N], unsigned int permutation[N]  );
void print_permutation( unsigned int permutation[N] );

#endif
